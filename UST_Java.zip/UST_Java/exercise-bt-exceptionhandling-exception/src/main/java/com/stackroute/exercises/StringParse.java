package com.stackroute.exercises;


public class StringParse {
    //Write logic to find the character from the sentence at specified location
    public char characterLocator(String sentence, String location) {

        return sentence.charAt(Integer.parseInt(location));
    }
}
