package com.stackroute.basics;

import java.util.Scanner;

public class Calculator {
    private static Scanner scan;

    // define,declare scanner and call getValues with scanner as parameter
    public static void main(String[] args) {
        scan = new Scanner(System.in);
        new Calculator().getValues(scan);



//        while (true) {
//
//            System.out.print("Do you want to try again(y/n)");
//            String ch= scan.next();
//            System.out.println(ch);
//            char choice = ch.charAt(0);
//            if (choice=='n') {
//                break;
//            }
//        }

    }

    //Get values and which operator from the menu
    public void getValues(Scanner scan) {
        char c=' ';
        String result="";
        do{
            int num1 = scan.nextInt();

            int num2 = scan.nextInt();
//
            int operator = scan.nextInt();
            c=scan.next().charAt(0);

           result= calculate(num1,num2,operator);

        }while (c=='y');
        System.out.println(result);
    }


    public String calculate(int firstValue, int secondValue, int operator)
    {

      int result;
      switch (operator) {
            case 1: // Addition
                result = firstValue + secondValue;
                return firstValue + " + " + secondValue + " = " + result;
            case 2: // Subtraction
                result = firstValue - secondValue;
                return firstValue + " - " + secondValue + " = " + result;
            case 3: // Multiplication
                result = firstValue * secondValue;
                return firstValue + " * " + secondValue + " = " + result;
            case 4: // Division
                if (secondValue == 0) {
                    return "The divider (secondValue) cannot be zero";
                }
                result =  firstValue / secondValue;
                return firstValue + " / " + secondValue + " = " + result;
            default:
                return "Entered wrong option "+operator;
                }
    }
}
