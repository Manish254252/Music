package in.stackroute;


import in.stackroute.domain.User;
import in.stackroute.service.UserServiceImpl;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {

        System.out.println("Hello world!");

        UserServiceImpl userService = new UserServiceImpl();

        User u1 = new User("mk11","quwuhj1727");

        userService.saveUser(u1.userName(), u1.password());
        userService.saveUser("mk2", "ksgdhk3646@@");
        userService.saveUser("mk3", "asdedhk3646@@");
        userService.saveUser("mk4", "ksgdhtejdb46@@");

    }
}