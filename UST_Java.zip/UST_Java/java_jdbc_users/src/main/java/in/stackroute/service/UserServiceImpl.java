package in.stackroute.service;

import in.stackroute.DBConnect.DBconnection;
import in.stackroute.domain.User;
import in.stackroute.repository.UserRepositoryImpl;

import java.sql.SQLException;
import java.util.Optional;

public class UserServiceImpl implements UserService{

    private UserRepositoryImpl userRepository;

    public UserServiceImpl() throws SQLException {
        userRepository = new UserRepositoryImpl(DBconnection.getInstance());
    }

    @Override
    public void saveUser(String userName, String password) throws SQLException {

        userRepository.saveUser(userName,password);

    }

    @Override
    public Optional<User> getUser(String userName) throws SQLException {
        Optional<User> user = userRepository.getUser(userName);
       return user;

    }

    @Override
    public void updateUser(String userName, String password) throws SQLException {

        userRepository.updateUser(userName,password);

    }

    @Override
    public void deleteUser(String userName) throws SQLException {

        userRepository.deleteUser(userName);

    }
}
