package in.stackroute.repository;

import java.sql.SQLException;
import java.util.Optional;

import in.stackroute.domain.User;

public interface UserRepository {

    int saveUser(String userName, String password) throws SQLException;

    Optional<User> getUser(String userName) throws SQLException;

    int updateUser(String userName, String password) throws SQLException;

    int deleteUser(String userName) throws SQLException;
}
