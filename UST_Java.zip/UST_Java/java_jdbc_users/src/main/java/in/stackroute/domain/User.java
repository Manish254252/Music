package in.stackroute.domain;

public record User(
    String userName,
    String password) {}
