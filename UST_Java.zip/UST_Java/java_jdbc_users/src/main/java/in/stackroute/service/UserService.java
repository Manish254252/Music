package in.stackroute.service;

import java.sql.SQLException;
import java.util.Optional;

import in.stackroute.domain.User;

public interface UserService {

  void saveUser(String userName, String password) throws SQLException;

  Optional<User> getUser(String userName) throws SQLException;

  void updateUser(String userName, String password) throws SQLException;

  void deleteUser(String userName) throws SQLException;

}
