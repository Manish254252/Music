package org.Manish;

import java.io.Serializable;

public class Trainee implements Serializable {
    private String name;

    public Trainee(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Trainee{" +
                "name='" + name + '\'' +
                '}';
    }
}
