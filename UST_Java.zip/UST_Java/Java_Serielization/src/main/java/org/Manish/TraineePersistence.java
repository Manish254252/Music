package org.Manish;

import java.io.*;
import java.util.LinkedList;
import java.util.List;

public class TraineePersistence {

    public void serialize(Trainee trainee) throws IOException {
        FileOutputStream out = new FileOutputStream("trainee.txt",true);
        ObjectOutputStream ser = new ObjectOutputStream(out);
        ser.writeObject(trainee);
        ser.flush();
        ser.close();

    }

    public List<Trainee> deSerialize() throws IOException, ClassNotFoundException {
        List<Trainee> traineeList = new LinkedList<>();
        FileInputStream in = new FileInputStream("trainee.txt");
        ObjectInputStream der = new ObjectInputStream(in);
        while (true) {
            try {
                Trainee tr = (Trainee) der.readObject();
                traineeList.add(tr);
            } catch (EOFException e) {
                break; // Break the loop when end of file is reached
            }
        }
        der.close();
        in.close();
        return traineeList;

    }
}
