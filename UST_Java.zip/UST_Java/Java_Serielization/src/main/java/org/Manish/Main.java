package org.Manish;

import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {

//        System.out.println("Hello world!");
        Trainee t1 = new Trainee("TraineeABC1");
        Trainee t2 = new Trainee("TraineeABC2");
        Trainee t3 = new Trainee("TraineeABC3");
        Trainee t4 = new Trainee("TraineeABC4");
        TraineePersistence tp = new TraineePersistence();
        tp.serialize(t1);
        tp.serialize(t2);
        tp.serialize(t3);
        tp.serialize(t4);
     List<Trainee>  temp=  tp.deSerialize();
     for (Trainee tr:temp)
     {
         System.out.println(tr);
     }

    }
}