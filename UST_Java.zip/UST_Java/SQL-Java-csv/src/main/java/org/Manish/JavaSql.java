package org.Manish;

import java.io.FileReader;
import java.util.Scanner;
import java.util.Scanner;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class JavaSql {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Take SQL query input from user
        System.out.print("Enter SQL query (e.g., SELECT * FROM data.csv WHERE condition): ");
        String sqlQuery = scanner.nextLine();

        // Read and process CSV file based on SQL query
        try (FileReader fileReader = new FileReader("data.csv");
             CSVParser csvParser = new CSVParser(fileReader, CSVFormat.DEFAULT.withHeader())) {

            List<CSVRecord> records = csvParser.getRecords();

            // Execute SQL query
            for (CSVRecord record : records) {
                // Implement logic to filter records based on SQL query
                // For demonstration purpose, simply print all records
                System.out.println(record);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        scanner.close();
    }
}
}

