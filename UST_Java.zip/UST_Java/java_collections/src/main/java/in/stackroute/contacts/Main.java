package in.stackroute.contacts;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        ContactManager cm = new ContactManagerR();
        ContactRecord record1 = new ContactRecord("Ashish s", "ashish.s", "Kerala", "12345");
        cm.store(record1);
        cm.find("ashish.s.panicker");
    }

    static void map(){
        Map<String, String> contacts = new HashMap();
        contacts.put("Batch", "SDET");
        contacts.put("Duration", "16");

        System.out.println(contacts.keySet());
        System.out.println(contacts.values());

        Set<Map.Entry<String, String>> entries = contacts.entrySet();
        for (Map.Entry<String, String> entry : entries){
            System.out.println(entry.getKey() + " = " + entry.getValue());
        }
    }

    static void list(){
        List<String> names = new ArrayList<>();
        names.add("Ashish");
        names.add("Ashwin");
        names.add("Sujith");
        find("Sujith", names);
        find("Arun", names);
    }

    static void find(String name, List<String> names){
        System.out.println("Searching....");
        if (names.isEmpty()){
            System.out.println("The list is empty.");
            return;
        }
        int index = names.indexOf(name);
        if(index == -1){
            System.out.println(String.format("Cannot find %s", name));
            return;
        }
        System.out.println(String.format("Found %s at position %s.", name, index));
        System.out.println();
    }

    static void print(Collection<String> list){
        System.out.println("Printing....");
        for (String name: list){
            System.out.println("Hello " + name);
        }
        System.out.println();
    }
}