package in.stackroute.contacts;

public record ContactRecord(
        String fullName,
        String email,
        String address,
        String phone
) {}
