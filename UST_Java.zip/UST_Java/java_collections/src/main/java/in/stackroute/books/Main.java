package in.stackroute.books;



public class Main {

    public static void main(String[] args) {
        BookRepository repository = new BookRepository();

        Book oldManSea = new Book("The Old Man and The Sea", "Ernest Hemingway", "Mcmillan");
        Book monteCristo = new Book("Count of Monte Cristo", "Alexander Dumas", "Mcmillan");
        Book pointOfLight = new Book("Point Of Light", "Kelly Gay", "343");
        Book animalFarm = new Book("Animal Farm", "George Orwell", "Penguin");

        repository.addBook(pointOfLight);
        repository.addBook(animalFarm);
        repository.addBook(oldManSea);
        repository.addBook(monteCristo);

        repository.printAll();

//        System.out.println("Searching...............");
//        repository.search("Animal farm");
//        repository.search("George Orwell");

        System.out.println("Sorting by Title");
        repository.sort(SortBy.TITLE);
        repository.printAll();

        System.out.println("Sorting by Author");
        repository.sort(SortBy.AUTHOR);
        repository.printAll();

        System.out.println("Sorting by Publisher");
        repository.sort(SortBy.PUBLISHER);
        repository.printAll();

    }
}
