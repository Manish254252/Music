package in.stackroute.books;

public enum SortBy {
    AUTHOR, PUBLISHER, TITLE
}
