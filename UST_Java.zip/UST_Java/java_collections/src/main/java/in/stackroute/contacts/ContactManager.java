package in.stackroute.contacts;

public interface ContactManager<K, V> {

    void store(V item);

    void find(K key);
}
