package in.stackroute.contacts;

public class ContactManagerC
        implements ContactManager<String, Contact> {

    @Override
    public void store(Contact item) {

    }

    @Override
    public void find(String key) {

    }
}
