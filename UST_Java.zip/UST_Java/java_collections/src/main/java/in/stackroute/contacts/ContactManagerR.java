package in.stackroute.contacts;

public class ContactManagerR implements ContactManager<String, ContactRecord> {

    @Override
    public void store(ContactRecord item) {

    }

    @Override
    public void find(String key) {

    }
}
