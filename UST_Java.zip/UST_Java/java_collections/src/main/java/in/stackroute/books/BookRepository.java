package in.stackroute.books;

import java.util.*;

public class BookRepository {

    private List<Book> books;

    public BookRepository() {
        books = new LinkedList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void printAll() {
        System.out.println("-----------------Books----------------------");
        for (Book book : books) {
            System.out.println(book);
        }
        System.out.println("-----------------------------------------------");
    }

    public void search(String key) {
        Map<String,Integer> map = new HashMap<>();
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(key) || book.getTitle().equalsIgnoreCase(key)) {
                System.out.println("Found the book.");
                System.out.println(book);
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void sort(SortBy sortBy) {
        switch (sortBy) {
            case TITLE:
                Collections.sort(books);
                break;
            case AUTHOR:
                Collections.sort(books, new AuthorSort());
                break;
            case PUBLISHER:
                Collections.sort(books, new PublisherSort());
                break;
        }
    }
}
