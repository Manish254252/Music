package org.Insurence;

public class HealthInsurance extends Insurance {
    private int healthCoverage;
    private double coverageLimit;
    private double deductible;

    public HealthInsurance(String policyNumber, String policyHolderName, double premium, int healthCoverage, double coverageLimit, double deductible) {
        super(policyNumber, policyHolderName, premium);
        this.healthCoverage = healthCoverage;
        this.coverageLimit = coverageLimit;
        this.deductible = deductible;
    }

    public int getHealthCoverage() {
        return healthCoverage;
    }

    public void setHealthCoverage(int healthCoverage) {
        this.healthCoverage = healthCoverage;
    }

    public double getCoverageLimit() {
        return coverageLimit;
    }

    public void setCoverageLimit(double coverageLimit) {
        this.coverageLimit = coverageLimit;
    }

    public double getDeductible() {
        return deductible;
    }

    public void setDeductible(double deductible) {
        this.deductible = deductible;
    }

    @Override
    public String toString() {
        return "HealthInsurance { " +"Name = "+getPolicyHolderName()+
                ", PolicyNumber = "+getPolicyNumber()+" Premium = "+getPremium()+
                " , healthCoverage='" + healthCoverage + '\'' +
                ", coverageLimit=" + coverageLimit +
                ", deductible=" + deductible +
                '}';
    }
}
