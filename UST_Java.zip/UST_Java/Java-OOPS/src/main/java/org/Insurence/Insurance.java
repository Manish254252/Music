package org.Insurence;

public class Insurance {

    private String policyNumber;
    private String policyHolderName;
    private double premium;

    // Constructor
    public Insurance(String policyNumber, String policyHolderName, double premium) {
        this.policyNumber = policyNumber;
        this.policyHolderName = policyHolderName;
        this.premium = premium;
    }

    // Getters and setters
    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getPolicyHolderName() {
        return policyHolderName;
    }

    public void setPolicyHolderName(String policyHolderName) {
        this.policyHolderName = policyHolderName;
    }

    public double getPremium() {
        return premium;
    }

    public void setPremium(double premium) {
        this.premium = premium;
    }

}
