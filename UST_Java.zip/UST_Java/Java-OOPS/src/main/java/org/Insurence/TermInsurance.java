package org.Insurence;

public class TermInsurance extends Insurance{
    private int term;
    private double coverageAmount;
    private String beneficiary;

    public TermInsurance(String policyNumber, String policyHolderName, double premium, int term, double coverageAmount, String beneficiary) {
        super(policyNumber, policyHolderName, premium);
        this.term = term;
        this.coverageAmount = coverageAmount;
        this.beneficiary = beneficiary;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    public double getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(double coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public String getBeneficiary() {
        return beneficiary;
    }

    public void setBeneficiary(String beneficiary) {
        this.beneficiary = beneficiary;
    }

    @Override
    public String toString() {
        return "TermInsurance { " +" Name = "+getPolicyHolderName()+
                ", PolicyNumber = "+getPolicyNumber()+" Premium = "+getPremium()+
                " term=" + term +
                ", coverageAmount=" + coverageAmount +
                ", beneficiary='" + beneficiary + '\'' +
                '}';
    }
}
