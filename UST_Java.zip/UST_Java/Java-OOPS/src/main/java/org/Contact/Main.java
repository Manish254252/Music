package org.Contact;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ContactManager contactManager = new ContactManager();

        boolean exit = false;
        while (!exit) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Add Contact");
            System.out.println("2. Search Contact by Name");
            System.out.println("3. Search Contact by Phone Number");
            System.out.println("4. Search Contact by Email");
            System.out.println("5. Update Contact");
            System.out.println("6. Delete Contact");
            System.out.println("7. Show All Contacts");
            System.out.println("8. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter contact details:");
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Phone Number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();

                    Contact newContact = new Contact(name, phoneNumber, email);
                    contactManager.addContact(newContact);
                    System.out.println("Contact added successfully.");


                    System.out.print("Do you want to continue? (yes/no): ");
                    String continueChoice = scanner.nextLine();
                    if (!continueChoice.equalsIgnoreCase("yes")) {
                        exit = true;
                        System.out.println("Exiting...");
                    }
                    break;

                case 2:
                    System.out.print("Enter name to search: ");
                    String searchName = scanner.nextLine();
                    Contact foundByName = contactManager.searchContactByName(searchName);
                    if (foundByName != null) {
                        System.out.println("Contact found: " + foundByName);
                    } else {
                        System.out.println("Contact not found.");
                    }
                    System.out.print("Do you want to continue? (yes/no): ");
                    continueChoice = scanner.nextLine();
                    if (!continueChoice.equalsIgnoreCase("yes")) {
                        exit = true;
                        System.out.println("Exiting...");
                    }
                    break;
                case 3:
                    System.out.print("Enter phone number to search: ");
                    String searchPhoneNumber = scanner.nextLine();
                    Contact foundByPhoneNumber = contactManager.searchContactByPhoneNumber(searchPhoneNumber);
                    if (foundByPhoneNumber != null) {
                        System.out.println("Contact found: " + foundByPhoneNumber);
                    } else {
                        System.out.println("Contact not found.");
                    }
                    System.out.print("Do you want to continue? (yes/no): ");
                     continueChoice = scanner.nextLine();
                    if (!continueChoice.equalsIgnoreCase("yes")) {
                        exit = true;
                        System.out.println("Exiting...");
                    }
                    break;
                case 4:
                    System.out.print("Enter email to search: ");
                    String searchEmail = scanner.nextLine();
                    Contact foundByEmail = contactManager.searchContactByEmail(searchEmail);
                    if (foundByEmail != null) {
                        System.out.println("Contact found: " + foundByEmail);
                    } else {
                        System.out.println("Contact not found.");
                    }
                    System.out.print("Do you want to continue? (yes/no): ");
                     continueChoice = scanner.nextLine();
                    if (!continueChoice.equalsIgnoreCase("yes")) {
                        exit = true;
                        System.out.println("Exiting...");
                    }
                    break;
                case 5:
                    // Add logic to update contact
                    break;
                case 6:
                    // Add logic to delete contact
                    break;
                case 7:
                    System.out.println("All Contacts:");
                    for (Contact contact : contactManager.getAllContacts()) {
                        System.out.println(contact);
                    }
                    System.out.print("Do you want to continue? (yes/no): ");
                     continueChoice = scanner.nextLine();
                    if (!continueChoice.equalsIgnoreCase("yes")) {
                        exit = true;
                        System.out.println("Exiting...");
                    }
                    break;
                case 8:

                        exit = true;
                        System.out.println("Exiting...");

                        break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
}

