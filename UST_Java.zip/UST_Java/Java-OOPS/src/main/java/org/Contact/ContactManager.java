package org.Contact;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ContactManager {

    private CopyOnWriteArrayList<Contact> contacts;

    // Constructor
    public ContactManager() {
        this.contacts = new CopyOnWriteArrayList<>();
    }

    // Method to add contact
    public void addContact(Contact contact) {
        contacts.add(contact);
    }
    public  Contact updateContactByName(String name,Contact upcontact)
    {
        for (Contact contact : contacts) {
            if (contact.getName().equalsIgnoreCase(name)) {
                contact.setName(upcontact.getName());
                contact.setEmail(upcontact.getEmail());
                contact.setPhoneNumber(upcontact.getPhoneNumber());
                return contact;
            }
        }
        System.out.println("No such Contact Found");
        return null;
    }
    // Method to remove contact
    public void removeContactByName(String name) {

        for (Contact contact : contacts) {
            if (contact.getName().equalsIgnoreCase(name)) {
                contacts.remove(contact);
                System.out.println("Contact Named: "+name+" removed  :");
            }
        }

    }

    // Method to search for contact by name
    public Contact searchContactByName(String name) {
        for (Contact contact : contacts) {
            if (contact.getName().equalsIgnoreCase(name)) {
                return contact;
            }
        }
        System.out.println("No such Contact Found");
        return null; // Contact not found
    }

    // Method to search for contact by phone number
    public Contact searchContactByPhoneNumber(String phoneNumber) {
        for (Contact contact : contacts) {
            if (contact.getPhoneNumber().equals(phoneNumber)) {
                return contact;
            }
        }
        return null; // Contact not found
    }

    // Method to search for contact by email
    public Contact searchContactByEmail(String email) {
        for (Contact contact : contacts) {
            if (contact.getEmail().equalsIgnoreCase(email)) {
                return contact;
            }
        }
        return null; // Contact not found
    }

    // Method to get all contacts
    public List<Contact> getAllContacts() {
        return contacts;
    }
}
