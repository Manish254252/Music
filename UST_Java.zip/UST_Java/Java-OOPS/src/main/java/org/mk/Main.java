package org.mk;

//import org.Insurence.HealthInsurance;
//import org.Insurence.TermInsurance;
//import org.UST.Book;
//import org.UST.Genere;
//import org.UST.Greeting;
//import org.UST.Math;
//import org.UST.Trainee;


import org.Contact.Contact;
import org.Contact.ContactManager;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
/*
  New keyword is used to create the object
  1.Memory allocation
  2.Member level initialization
  3.constructor invocation
  4.memory reference returned to the object
 */

//        Greeting greetObj = new Greeting();
//        greetObj.greet();
//
//        Trainee tr = new Trainee();
//        tr.setFullname("Manish Solanki");
//        tr.setDepartment("SDET");
//        tr.setEmail("Mk@ust.com");
//        tr.setEmpId(280708);
//        System.out.println(tr);

//        Book bk= new Book("Harry Potter","J. K. Rowling",1234567890, Genre.ACTION.toString(),"Bloomsbury",4.61);
//        System.out.println(bk);
//
//        Math math = new Math();
//        System.out.println(math.sum(1,2,3,4,5,5));
//
//        HealthInsurance hi = new HealthInsurance("2536379","Manish",1500.0,35,450000,50000);
//        System.out.println(hi);
//        TermInsurance ti = new TermInsurance("2536379","Manish",1500.0,500000,450000,"Manish");
//        System.out.println(ti);


//        List<String> list = new ArrayList<>();
//        List<String> list1 = new LinkedList<>();
//
//        list.add("Mk");
//        list.add("Mk1");
//        list.add("Mk2");
//        list.add("Mk3");
//        list.add("Mk4");
//        list.add("Mk5");

//
//        list1.add("Manish");
//        list1.add("Manish1");
//        list1.add("Manish2");
//        list1.add("Manish3");
//        list1.add("Manish4");
//        list1.add("Manish5");
//        list1.add("Manish6");
//
//        list1.remove("Manish5");
//        list.remove("Mk5");
//
//        printList(list);
//        printList(list1);

        Contact con = new Contact("Manish","9037382872","Mk@ust.com");
        ContactManager conm = new ContactManager();
        conm.addContact(new Contact("Manish","9037382872","Mk1@ust.com"));
        conm.addContact(new Contact("Manish1","9037382872","Mk2@ust.com"));
        conm.addContact(new Contact("Manish2","9037382872","Mk3@ust.com"));
        conm.addContact(new Contact("Manish3","9037382872","Mk4@ust.com"));
        conm.addContact(new Contact("Manish4","9037382872","Mk5@ust.com"));
        conm.addContact(new Contact("Manish5","9037382872","Mk6@ust.com"));
        conm.addContact(new Contact("Manish6","9037382872","Mk7@ust.com"));

       List<Contact> contactList = conm.getAllContacts();
//       printList(contactList);
//       Contact temp1 = conm.searchContactByEmail("Mk4@ust.com");
//        System.out.println(temp1+"search by email");
//        Contact temp2 = conm.searchContactByName("Manish1");
//        System.out.println(temp2+"search by Name");
////        conm.removeContact();
//        conm.removeContactByName("Manish2");
//        printList(contactList);
    Contact contact=conm.updateContactByName("Manish",new Contact("ManishSolanki","8567380987","Mk24@ust.com"));
        System.out.println(contact);

    }

    private static void printList(List<Contact> list1) {
        for (Contact x:list1)
        {
            System.out.println(x);
        }
    }
}
