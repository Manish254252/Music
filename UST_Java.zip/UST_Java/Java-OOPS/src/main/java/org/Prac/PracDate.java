package org.Prac;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;



public class PracDate {
    public static void main(String[] args) {
        LocalDate date = LocalDate.now();
        System.out.println(date);
        System.out.println(date);


        LocalDateTime dta =LocalDateTime.now();
        System.out.println(dta);
        int a = dta.getHour();

        System.out.println(a);
        LocalTime time = LocalTime.now();

        System.out.println(time.getMinute());
        DateTimeFormatter dtf= DateTimeFormatter.ofPattern("hh:mm:ss a");
        String dth=time.format(dtf);
        System.out.println(dth);
    }
}
