package org.Prac;

public class StringDemo {

    public static void main(String[] args) {
        String s = "geeks quiz practice code";
        char[] arr = s.toCharArray();
        String[] strarr = new String[arr.length];
        String temp = "";
        int i = 0;
        for (char x : arr) {
            if (x != ' ') {
                temp += x;
            } else {
                strarr[i] = temp;
                i++;
                temp = "";
            }
        }
        // Add the last word to the array
        strarr[i] = temp;

        // Print the words in reverse order
        for (int j = strarr.length - 1; j >= 0; j--) {
            if (strarr[j] != null) {
                System.out.println(strarr[j]);
            }
        }
    }
}
