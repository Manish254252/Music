package org.Prac;


import java.util.Arrays;

public class Hom {

    public static void main(String[] args) {
        int []array={1,1,2,2,2,2,2};
        Arrays.sort(array);
//        System.out.println(array[0]);
    int n = array[array.length-1]+2;
        int []num=new int[n];
        for (int j : array) {
            num[j]++;

        }
        for (int i = 0; i < num.length; i++) {

            if(num[i]>1)
            {
                System.out.println(i+",");
            }
        }


    }
}
