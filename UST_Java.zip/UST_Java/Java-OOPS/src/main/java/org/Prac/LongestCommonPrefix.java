package org.Prac;


public class LongestCommonPrefix {

    public static String longestCommonPrefix(String[] strs) {
        if (strs == null || strs.length == 0) {
            return "";
        }
        char[] st1 = strs[0].toCharArray();
        char[] st2 = strs[1].toCharArray();
        String ans = "";
        int i = 0, j = 0;
        while (i < st1.length && j < st2.length) {
            if (st1[i] == st2[j]) {
                ans =ans+ st1[i] + "";
//                System.out.println(ans);
            }
            i++;
            j++;

        }
        for (int k = 2; k <strs.length ; k++) {
            while(!strs[k].contains(ans))
            {
                ans=ans.substring(0,ans.length()-1);
            }
        }

        return ans;
    }





    public static void main(String[] args) {
        String[] input1 = {"geeksforgeeks", "geeks", "geek", "geezer"};
        String[] input2 = {"apple", "ape", "april"};

        System.out.println("Longest common prefix for input1: " + longestCommonPrefix(input1));
        System.out.println("Longest common prefix for input2: " + longestCommonPrefix(input2));
    }
}
