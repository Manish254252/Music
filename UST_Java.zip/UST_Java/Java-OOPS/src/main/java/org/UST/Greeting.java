package org.UST;

public class Greeting {
    String message;
    int age ;
    public static void main(String[] args) {

    }
    public void greet()
    {
        System.out.println("Hello there");
        System.out.println(message);
        System.out.println(age);
    }
}
