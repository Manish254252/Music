package org.UST;

public class Book {

    private String BookName;
    private String Author;
    private long isbnNo;
    private Genere Genera;
    private  String Publisher;
    private double Rating;

    public Book(String bookName, String author, long isbnNo, String genera, String publisher, double rating) {
       this.BookName = bookName;
        this.Author = author;
        this.isbnNo = isbnNo;
        this.Genera = Genere.valueOf(genera);
        this.Publisher = publisher;
        this.Rating = rating;
    }

    public Book() {
    }

    public String getBookName() {
        return BookName;
    }

    public void setBookName(String bookName) {
        this.BookName = bookName;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        this.Author = author;
    }

    public long getIsbnNo() {
        return isbnNo;
    }

    public void setIsbnNo(long isbnNo) {
        this.isbnNo = isbnNo;
    }

    public Genere getGenera() {
        return Genera;
    }

    public void setGenere(String genera) {
        this.Genera = Genere.valueOf(genera);
    }

    public String getPublisher() {
        return Publisher;
    }

    public void setPublisher(String publisher) {
        this.Publisher = publisher;
    }

    public double getRating() {
        return Rating;
    }

    public void setRating(double rating) {
       if(rating>0 && rating<=5)
       {
           this.Rating = rating;
       }else {
           System.out.println("provide rating between 0 to 5 ");
       }
    }

    @Override
    public String toString() {
        return "Book{" +
                "BookName='" + BookName + '\'' +
                ", Author='" + Author + '\'' +
                ", isbnNo=" + isbnNo +
                ", Genera='" + Genera + '\'' +
                ", Publisher='" + Publisher + '\'' +
                ", Rating=" + Rating +
                '}';
    }
}
