package org.UST;

import java.util.Objects;

public class Trainee {

    private String fullname;
    private  String department;
    private  String email;
    private long empId;

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getEmpId() {
        return empId;
    }

    public void setEmpId(long empId) {
        String id=empId+"";
       if(id.length()>=6)
       {
           this.empId = empId;
       }else {
           System.out.println("error empID should be 6 digits");
       }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Trainee trainee = (Trainee) o;
        return empId == trainee.empId && Objects.equals(fullname, trainee.fullname) && Objects.equals(department, trainee.department) && Objects.equals(email, trainee.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fullname, department, email, empId);
    }

    @Override
    public String toString() {
        return "Trainee{" +
                "FullName='" + fullname + '\'' +
                ", department='" + department + '\'' +
                ", email='" + email + '\'' +
                ", empId=" + empId +
                '}';
    }
}
