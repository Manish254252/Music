package org.UST;


public enum Genere {
    ACTION,
    COMEDY,
    DRAMA,
    HORROR,
    ROMANCE,
    SCIENCE_FICTION,
    THRILLER
}

