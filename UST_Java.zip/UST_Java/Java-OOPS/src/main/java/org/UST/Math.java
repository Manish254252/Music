package org.UST;

public class Math {
    public static void main(String[] args) {

    }
    public long sum(long...values){
        long sum=0;
        for(long val : values)
        {
            sum+=val;
        }
        return sum;
    }
}
