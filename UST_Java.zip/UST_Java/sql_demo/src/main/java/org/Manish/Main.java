package org.Manish;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.Manish.Model.Todo;
import org.Manish.TodoDAL.TodoDal;

public class Main {
    public static void main(String[] args) throws NullPointerException, SQLException {
       

        Todo todo = new Todo(11, "The Abc",'Y',LocalDate.now());

        TodoDal tododal = new TodoDal(DbConnection.getInstance());
        
//        System.out.println(tododal.create(todo));
         List<Todo> todoList = tododal.findAll();
         todoList.forEach(System.out::println);

Optional<Todo> todo1 =  tododal.findOne(5);
        System.out.println(todo1);

//        tododal.update(new Todo(12,"asd fgh ",'Y',LocalDate.now()));
        tododal.delete(todo);
    }
}