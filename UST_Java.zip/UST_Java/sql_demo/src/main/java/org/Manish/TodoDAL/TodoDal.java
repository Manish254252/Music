package org.Manish.TodoDAL;



import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.Manish.Model.Todo;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class TodoDal {


  private final Connection connection;
  private static final String INSERT_QUERY = 
    "insert into todo (reminder, status, create_at) values (?, ?, ?)";

  private static final String UPDATE_QUERY = 
    "update todo set reminder = ?, status = ?, create_at = ? where id = ?";

  private static final String DELETE_QUERY = 
    "delete from todo where id = ?";

  private static final String FIND_ONE_QUERY = 
    "select id, reminder, status, create_at from todo where id = ?";

  private static final String FIND_ALL_QUERY = 
    "select id, reminder, status, create_at from todo";

  public int create(Todo todo) throws SQLException {
    try (PreparedStatement ps = connection.prepareStatement(INSERT_QUERY)) {
      ps.setString(1, todo.getReminder());
      ps.setString(2, String.valueOf(todo.getStatus()));
      ps.setDate(3, Date.valueOf(todo.getCreated_at()));
      int rows = ps.executeUpdate();
      ps.close();
      return rows;
    }
  }

  public int update(Todo todo) throws SQLException {
    int rows = 0;
    try (PreparedStatement ps = connection.prepareStatement(UPDATE_QUERY)) {
      ps.setString(1, todo.getReminder());
      ps.setString(2, String.valueOf(todo.getStatus()));
      ps.setDate(3, Date.valueOf(todo.getCreated_at()));
      ps.setInt(4, todo.getId());
      rows = ps.executeUpdate();
      ps.close();
    }
    return rows;
  }

  public int delete(Todo todo) throws SQLException {
    int rows = 0;
    try (PreparedStatement ps = connection.prepareStatement(DELETE_QUERY)) {
      ps.setInt(1, todo.getId());
      rows = ps.executeUpdate();
      ps.close();
    }
    return rows;
  }

  public Optional<Todo> findOne(int id) throws SQLException {
    try (PreparedStatement ps = connection.prepareStatement(FIND_ONE_QUERY)) {
      ps.setInt(1, id);
      ResultSet rs = ps.executeQuery();
      Todo todo = null;
      if (rs.next()) {
        todo = new Todo();
        todo.setId(rs.getInt("id"));
        todo.setReminder(rs.getString("reminder"));
        todo.setStatus(rs.getString("status").charAt(0));
        todo.setCreated_at(rs.getDate("create_at").toLocalDate());
      }
      rs.close();
      ps.close();
      return Optional.ofNullable(todo);
    }
  }

  // find all method 

  public List<Todo> findAll() throws SQLException{
    try (PreparedStatement ps = connection.prepareStatement(FIND_ALL_QUERY)) {
      ResultSet rs = ps.executeQuery();
      List<Todo> todos = new java.util.ArrayList<>(List.of());
      while (rs.next()) {
        Todo todo = new Todo();
        todo.setId(rs.getInt("id"));
        todo.setReminder(rs.getString("reminder"));
        todo.setStatus(rs.getString("status").charAt(0));
        todo.setCreated_at(rs.getDate("create_at").toLocalDate());
        todos.add(todo);
      }
      rs.close();
      ps.close();
      return todos;
    }
  }

}
