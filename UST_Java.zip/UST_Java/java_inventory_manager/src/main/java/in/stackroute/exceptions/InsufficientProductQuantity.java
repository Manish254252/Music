package in.stackroute.exceptions;

public class InsufficientProductQuantity extends Exception {

    public InsufficientProductQuantity()
    {
        super();
    }

    public InsufficientProductQuantity(String msg)
    {
        super(msg);
    }
}
