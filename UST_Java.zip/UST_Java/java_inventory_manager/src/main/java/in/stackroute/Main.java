package in.stackroute;

import in.stackroute.cart.Cart;
import in.stackroute.exceptions.CartItemNotFoundException;
import in.stackroute.exceptions.ProductExpired;
import in.stackroute.exceptions.ProductOutOfStockException;
import in.stackroute.inventory.Inventory;
import in.stackroute.item.Item;
import in.stackroute.product.Product;
import in.stackroute.product.UsagePeriod;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ProductOutOfStockException, ProductExpired, CartItemNotFoundException, SQLException {
        Inventory in = new Inventory();
        Scanner sc = new Scanner(System.in);
        String productchoice =" ";

        Item it1 = new Item(new Product("123","Prabc1",456.09f,LocalDate.of(2024,05,12),25,UsagePeriod.MONTHS),50);
        Item it2 = new Item(new Product("456","Prodc2",426.04f,LocalDate.of(2024,05,12),25,UsagePeriod.MONTHS),50);
        Item it3 = new Item(new Product("789","Probc3",416.00f,LocalDate.of(2024,05,12),25,UsagePeriod.MONTHS),50);
        Item it4 = new Item(new Product("012","Prabc4",556.02f,LocalDate.of(2024,05,12),25,UsagePeriod.MONTHS),50);
        Item it5 = new Item(new Product("234","Probc5",956.01f,LocalDate.of(2024,05,12),25,UsagePeriod.MONTHS),50);
        Item it6 = new Item(new Product("345","Prc6",426.09f,LocalDate.of(2024,05,12),25,UsagePeriod.MONTHS),50);
        Item it7 = new Item(new Product("678","Pdabc7",459.09f,LocalDate.of(2024,05,12),25,UsagePeriod.MONTHS),50);

        in.addItem(it1);
        in.addItem(it2);
        in.addItem(it3);
        in.addItem(it4);
        in.addItem(it5);
        in.addItem(it6);
        in.addItem(it7);



//        Cart cv= new Cart();
//        cv.addItem("123",5);
//        cv.addItem("234",5);
//        cv.addItem("456",5);

//        cv.removeItem("234");

//        String answer="y";
//        while(!answer.equalsIgnoreCase("n"))
//        {
//            in.getAllInventory();
//            System.out.println("which Products you would like to add :");
//            System.out.println("Enter the code for that Product");
//            productchoice = sc.nextLine();
//            System.out.println("Enter the QUANTITY for that Product");
//            int x = sc.nextInt();
//            sc.nextLine();
//            cv.addItem(productchoice,x);
//            System.out.println("Do you want to add more Product :(y/n)");
//            answer = sc.nextLine();
//            System.out.println("Do you want to remove items : (y/n)");
//
//        }
//
//
//
//        cv.checkout();




    }
}