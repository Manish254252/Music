package in.stackroute.cart;

import in.stackroute.item.Item;
import in.stackroute.product.Product;

public class CartItem extends Item {

    private float totalPrice;

    public CartItem(Product product, int quantity) {
        super(product, quantity);
        // calculate totalPrice
    }

    public float getTotalPrice() {
        return totalPrice;
    }
}
