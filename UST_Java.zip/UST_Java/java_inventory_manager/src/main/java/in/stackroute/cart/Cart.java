package in.stackroute.cart;

import in.stackroute.exceptions.CartItemNotFoundException;
import in.stackroute.exceptions.ProductExpired;
import in.stackroute.exceptions.ProductOutOfStockException;
import in.stackroute.inventory.Inventory;
import in.stackroute.item.Item;

import java.util.LinkedList;
import java.util.List;

public class Cart {

    private List<Item> cartItems;
    private float grossTotal;
    private Inventory inv;


    public Cart() {
        cartItems = new LinkedList<>();
    }

    public float getGrossTotal() {
        return grossTotal;
    }

    /**
     * Calculate the grossTotal of the cart after an item is added or removed from the cart.
     */
    private void calculateGrossTotal() {
        for(Item it : cartItems)
        {
            grossTotal=it.getProduct().getUnitPrice()*it.getQuantity();

        }
    }

    /**
     * Add a Product to the CartItem.
     * Verify that the product is available and not expired and product is in stock before adding to the cart.
     * If the Item is expired then ProductExpiredException exception must be thrown.
     * If the Item is not in stock then ProductOutOfStockException must be thrown.
     * Update the inventory with the new stock.
     *
     * @param code     The item code which going to be added to the cart.
     * @param quantity the quantity of the Item
     */
    public void addItem(String code, int quantity) throws ProductExpired,ProductOutOfStockException{
        Item additem = new Item();
        for(Item it:Inventory.inventory)
        {

            if (it.getProduct().getCode().equalsIgnoreCase(code))
            {

                if(it.getProduct().isExpired())
                {
                    throw new ProductExpired("This product can't be added It's expired");
                }
                if(it.getQuantity()<quantity)
                {
                    throw new ProductOutOfStockException("Not in stock");
                }
                additem.setProduct(it.getProduct());
                additem.setQuantity(quantity);
//                additem.setProduct(it.getProduct());
                cartItems.add(additem);
                Inventory.updateStock(code,quantity);

            }
        }

    }

    /**
     * Remove the item with the corresponding code if found in the cart.
     * If item is not found then CartItemNotFoundException is raised.
     * Update the inventory with the new stock.
     *
     * @param code The item code which has to be removed from the cart.
     */
    public void removeItem(String code) throws CartItemNotFoundException {

        boolean ans = cartItems.removeIf(it -> it.getProduct().getCode().equalsIgnoreCase(code));
        if(!ans)
        {
            throw new CartItemNotFoundException("The item does not exists so can't be removed");
        }
    }

    /**
     * Clear the cart and print the final bill in a tabular format.
     */
    public void checkout() {
//        System.out.println("in checkout");
        float totalBill = 0;
        for(Item x:cartItems)
        {

//            calculateGrossTotal();
            System.out.println("---------------------------------------------------------------------");
            System.out.println("Product Name = "+x.getProduct().getName());
//            System.out.println(x.getQuantity());
            totalBill+=x.getProduct().getUnitPrice()*x.getQuantity();
            System.out.println("Product Unit price : "+x.getProduct().getUnitPrice()+"  X  Quantity :"+x.getQuantity());
            System.out.println("Product Price = "+x.getProduct().getUnitPrice()*x.getQuantity());
//            System.out.println(grossTotal);
        }
        System.out.println("======================================================================");
        System.out.println("TotalBill : "+totalBill);
    }
    public void getAllInventory() {
        for (Item items:cartItems)
        {
            System.out.println(items);
        }

    }

}
