package in.stackroute.product;

import in.stackroute.item.Item;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Product extends Item {

    private String code;
    private String name;
    private float unitPrice;
    private LocalDate manufacturedDate;
    private int usableDuration;
    private UsagePeriod period;

    public Product(String code, String name, float unitPrice, LocalDate manufacturedDate,
                   int usableDuration, UsagePeriod period) {
        super();
        this.code = code;
        this.name = name;
        this.unitPrice = unitPrice;
        this.manufacturedDate = manufacturedDate;
        this.usableDuration = usableDuration;
        this.period = period;
    }



    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(float unitPrice) {
        this.unitPrice = unitPrice;
    }

    public LocalDate getManufacturedDate() {
        return manufacturedDate;
    }

    public void setManufacturedDate(LocalDate manufacturedDate) {
        this.manufacturedDate = manufacturedDate;
    }

    public int getUsableDuration() {
        return usableDuration;
    }

    public void setUsableDuration(int usableDuration) {
        this.usableDuration = usableDuration;
    }

    public UsagePeriod getPeriod() {
        return period;
    }

    public void setPeriod(UsagePeriod period) {
        this.period = period;
    }

    /**
     * Check if the producted is expired based on the manufacturedDate, ussableDuration and period.
     *
     * @return boolean
     */
    public boolean isExpired() {
        LocalDate expiredDate = manufacturedDate.plusDays(usableDuration);
        LocalDate current = LocalDate.now();
        return expiredDate.isBefore(current);
    }


    @Override
    public String toString() {
        return "Product{" +
                "code='" + code + '\'' +
                ", name='" + name + '\'' +
                ", unitPrice=" + unitPrice +
                ", manufacturedDate=" + manufacturedDate +
                ", usableDuration=" + usableDuration +
                ", period=" + period +
                '}';
    }
}
