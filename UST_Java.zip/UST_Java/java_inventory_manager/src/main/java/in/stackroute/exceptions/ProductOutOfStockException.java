package in.stackroute.exceptions;

public class ProductOutOfStockException extends Exception{

    public ProductOutOfStockException()
    {
        super();
    }

    public ProductOutOfStockException(String msg)
    {
        super(msg);
    }
}
