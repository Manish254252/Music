package in.stackroute.exceptions;

public class ProductExpired extends Exception{

    public ProductExpired()
    {
        super();
    }
    public ProductExpired(String msg)
    {
        super(msg);
    }
}
