package in.stackroute.exceptions;

public class CartItemNotFoundException extends Exception{

    public CartItemNotFoundException()
    {
        super();
    }
    public CartItemNotFoundException(String msg)
    {
        super(msg);
    }

}
