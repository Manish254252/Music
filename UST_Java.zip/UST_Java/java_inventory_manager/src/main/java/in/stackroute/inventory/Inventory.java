package in.stackroute.inventory;

import in.stackroute.DB.DbConnection;
import in.stackroute.exceptions.CartItemNotFoundException;
import in.stackroute.exceptions.ProductNotFoundException;
import in.stackroute.exceptions.ProductOutOfStockException;
import in.stackroute.item.Item;
import in.stackroute.product.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class Inventory {

    public static List<Item> inventory;
    static Connection connection;

    static {
        try {
            connection = DbConnection.getInstance();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Inventory() throws SQLException {
        inventory = new LinkedList<>();
    }

    /**
     * Add a new item to the inventory. If the item is already present in the inventory
     * then update the quantity of that item.
     * @param item      The item which is going to be added to the inventory.
     */
    public void addItem(Item item) {
        boolean exists = false;
        for(Item i : inventory)
        {
            if(i.getProduct().getCode().equalsIgnoreCase(item.getProduct().getCode()))
            {
                exists=true;
                i.setQuantity(i.getQuantity()+item.getQuantity());

            }

        }
       if(!exists) {
           inventory.add(item);
           String sql = "INSERT INTO Items (code, name, unit_price, manufactured_date, quantity) VALUES (?, ?, ?, ?, ?)";

           try (PreparedStatement statement = connection.prepareStatement(sql)) {
               statement.setString(1, item.getProduct().getCode());
               statement.setString(2, item.getProduct().getName());
               statement.setFloat(3, item.getProduct().getUnitPrice());
               statement.setDate(4, java.sql.Date.valueOf(item.getProduct().getManufacturedDate()));
               statement.setInt(5, item.getQuantity());

               // Execute the INSERT statement
               statement.executeUpdate();
       }
           catch (SQLException e) {
               throw new RuntimeException(e);
           }


       }}

    /**
     * Once an items are added to the cart or removed from the cart, the inventory needs to
     * be updated with the new stock.
     *
     * @param code     The code of the product
     * @param quantity The number of units of product which was requested
     */
    public static void updateStock(String code, int quantity) {

        for(Item it:inventory)
        {
            if (it.getProduct().getCode().equalsIgnoreCase(code))
            {
                it.setQuantity(it.getQuantity()-quantity);
                String sql = "UPDATE Items SET quantity = ? WHERE code = ?";

                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, quantity);
                    statement.setString(2, code);

                    int rowsUpdated = statement.executeUpdate();
                    if (rowsUpdated == 0) {
                        throw new SQLException("Failed to update item with code: " + code);
                    }
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }

    /**
     * Remove the item form the inventory.
     *
     * @param code The code of the item that needs to be removed from the inventory.
     */
    public void removeItem(String code) throws CartItemNotFoundException {
        boolean ans = inventory.removeIf(it -> it.getProduct().getCode().equalsIgnoreCase(code));
        if(!ans)
        {
            throw new CartItemNotFoundException("The item does not exists so can't be removed");
        }
        if(ans)
        {
            String sql = "DELETE FROM Items WHERE code = ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, code);

                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted == 0) {
                    throw new SQLException("Failed to delete item with code: " + code);
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

    }

    /**
     * Check if the Item is in stock in the inventory.
     * If product is not present then ProductOutOfStockException must be thrown.
     * If product is not in sufficient quantity then InsufficientProductQuantity exception must be thrown.
     *
     * @param code     The code of the product
     * @param quantity The number of units of product which was requested
     * @return true if the product is present in the requested quantity;
     */
    public boolean isInStock(String code, int quantity) throws ProductOutOfStockException {

        for(Item it:inventory)
        {
            if (it.getProduct().getCode().equalsIgnoreCase(code))
            {
             if(it.getQuantity()>=quantity)
             {
                 return true;
             }else {
                 throw new ProductOutOfStockException("Product is out of stock for now");
             }
            }
        }
        return false;
    }

    /**
     * Find if the Product with this code exists in the inventory. If found return the product.
     * If not found then raise ProductNotFoundException.
     *
     * @param code Code of the item to be searched.
     * @return Product if the code is present
     */
    public Product find(String code) throws ProductNotFoundException {
        for(Item it:inventory)
        {
            if (it.getProduct().getCode().equalsIgnoreCase(code))
            {
                return (Product) it;
            }else {
                throw new ProductNotFoundException("Product not found ");
            }
        }

        return null;
    }

    public void getAllInventory() throws SQLException {
        System.out.println("ProductName " +" Code "+"  Unit Price");
        for (Item items:inventory)
        {

            System.out.print(items.getProduct().getName()+"     ");
            System.out.print(items.getProduct().getCode()+"   ");
            System.out.println(items.getProduct().getUnitPrice());
//           System.out.println(items.getProduct().getName());
        }



    }
    public List<Item> getInvenList()
    {
        return inventory;
    }

    @Override
    public String toString() {
        return "Inventory{" +
                "inventory=" + inventory +
                '}';
    }
}
