package in.stackroute.product;

public enum UsagePeriod {
    DAYS, MONTHS, YEARS
}
