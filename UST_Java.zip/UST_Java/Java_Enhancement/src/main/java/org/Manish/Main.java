package org.Manish;

import org.Manish.SealedClass.DemoSeal;
import org.Manish.Shapes.Circle;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

//        var mk = "Strig";
//        Circle cl = new Circle();
//
//        System.out.println(cl.getClass().getSimpleName());



//        System.out.println(mk.getClass().getTypeName());

        DemoSeal dm = new DemoSeal();
        String str = Arrays.toString(dm.getClass().getPermittedSubclasses());

        System.out.println(dm.getClass().getSimpleName());

    }
}