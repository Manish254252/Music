package org.Manish.OPT;

import java.sql.Connection;
import java.util.Optional;

public class StringAndOpt {
   private String str = null;
   private Connection connection=null;
    public static void main(String[] args) {
        StringAndOpt sto = new StringAndOpt();
        sto.stringMethod();
        sto.option();
    }
    public void option()
    {
        Optional<String> opstr=Optional.ofNullable(str);
        Optional<Connection> conn=Optional.ofNullable(connection);
        System.out.println(opstr.orElse("jqdheq"));
        System.out.println(conn);
    }
    public void stringMethod()
    {
//        System.out.println("isblanck "+str.isBlank());
//        System.out.println("isblanck "+str.isEmpty());
    }
}
