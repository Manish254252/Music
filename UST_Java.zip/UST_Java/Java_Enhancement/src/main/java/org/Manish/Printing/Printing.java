package org.Manish.Printing;
@FunctionalInterface
public interface Printing {

   void print();
}
