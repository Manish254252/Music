package org.Manish.SealedClass;

public sealed interface DD extends DD2 permits Demo2 {
}
