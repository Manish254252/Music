package org.Manish.SealedClass;

public sealed class DemoSeal permits Demo1,Demo2 {
}
