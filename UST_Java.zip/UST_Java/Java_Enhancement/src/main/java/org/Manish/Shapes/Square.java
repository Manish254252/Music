package org.Manish.Shapes;

public class Square implements Shape {
    @Override
    public double area() {
        return 0;
    }

    @Override
    public double perimeter() {
        return 0;
    }
}
