package org.Manish.SealedClass;

public non-sealed class Demo3 extends Demo2 {
}
