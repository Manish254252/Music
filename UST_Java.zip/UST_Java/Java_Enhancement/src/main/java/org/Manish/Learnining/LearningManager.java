package org.Manish.Learnining;

public class LearningManager {
    Trainee t1 = new Trainee("1233te","Abc","Dev","Sdet");
    Trainee t2 = new Trainee("2233te","Abc","Dev","Sdet");
    Trainee t3 = new Trainee("3233te","Abc","Dev","Sdet");
    Trainee t4 = new Trainee("4233te","Abc","Dev","Sdet");

    public static void main(String[] args) {

        LearningManager lm = new LearningManager();
        String textBlock= """
                Hello there how are you 
                    nice to meet you 
                hello """;
        lm.add();
        System.out.println(textBlock);

    }
    public  void add()
    {
        System.out.println(t1.empId());
        System.out.println(t2.empId());
        System.out.println(t3.empId());
        System.out.println(t4.empId());
    }
}
