package org.Manish.SealedClass;

public interface DD2 {
}
