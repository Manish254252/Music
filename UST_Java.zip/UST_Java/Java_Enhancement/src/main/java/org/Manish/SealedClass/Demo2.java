package org.Manish.SealedClass;

public sealed class Demo2 extends DemoSeal implements DD permits Demo3 {
}
