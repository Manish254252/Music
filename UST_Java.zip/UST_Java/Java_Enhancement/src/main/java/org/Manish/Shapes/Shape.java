package org.Manish.Shapes;

public interface Shape {
    double area();
    double perimeter();

   default void drawShape()
    {
        System.out.println("in drawShape");
    }
    static void printShape(){
        System.out.println("in printShape");
    }

}
