package org.Manish.Printing;

public class FilePrint implements Printing{
    @Override
    public void print() {

    }
}
