package org.Manish;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class DatePrac {

    public static void main(String[] args) {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate date = LocalDate.parse("2024-03-24");


        LocalTime time = LocalTime.now(ZoneId.of("GMT+"+"05:30"));
        System.out.println(date.format(format));
        System.out.println(date.getMonthValue());
        System.out.println(time);
    }
}
