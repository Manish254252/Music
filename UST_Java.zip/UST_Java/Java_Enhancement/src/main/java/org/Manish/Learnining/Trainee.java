package org.Manish.Learnining;

public record Trainee(String empId,String fullName,String designation,String department) {
}
