package org.Manish.Shapes;

public class ShapeManager {
    public void drawShape(Shape shape)
    {
        if(shape instanceof Circle c)
        {
            c.drawShape();
        } else if (shape instanceof Square s) {
            s.drawShape();
        }
    }
}
