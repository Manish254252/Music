package org.Manish.SealedClass;

public non-sealed class Demo1 extends DemoSeal {
}
