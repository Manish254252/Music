package com.stackroute.strings;

public class LongestSubString {

    //write logic to find the longest substring that appears at both ends of a given string and return result
    public StringBuilder findLongestSubString(StringBuilder input) {
        if (input == null || input.isEmpty()) {
            return new StringBuilder("Give proper input");
        }
    int length = input.length();

    StringBuilder fp= new StringBuilder(input.substring(0, length / 2+1));
    StringBuilder sp= new StringBuilder(input.substring(length/2, length ));

    StringBuilder temp = new StringBuilder("");
    StringBuilder temp1 = new StringBuilder("");
    int j=0,i=0;
    while(i<fp.length() && j< sp.length())
    {
        if(fp.charAt(i)==sp.charAt(j))
        {
            temp.append(fp.charAt(i));
            temp1.append(fp.charAt(j));
            i++;
            j++;

        }else {
            j++;
        }


    }


       if(temp.length()==0)
           return new StringBuilder("Longest substring is not present in the given StringBuilder");
       if(input.charAt(input.length()-1)!=temp.charAt(temp.length()-1))
       {
           return new StringBuilder("Longest substring is not present in the given StringBuilder");
       }
       return temp;
    }
}
