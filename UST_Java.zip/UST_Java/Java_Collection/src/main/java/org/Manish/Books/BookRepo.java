package org.Manish.Books;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

public class BookRepo {

    private List<Book> books;

    public BookRepo()
    {
        books = new LinkedList<>();
    }

    public void addBooks(Book book) {
        books.add(book);
    }
    public void getAllBooks()
    {
        books.forEach(System.out::println);
    }
    public void serach(String key)
    {
     for (Book bk:books)
     {
         if(bk.getTitle().equalsIgnoreCase(key) || bk.getAuthor().equalsIgnoreCase(key))
         {

             System.out.println("Found the book");
             System.out.println(bk);
             return;
         }
     }
        System.out.println("Book not Found");
    }
}
