package org.Manish;

import org.Manish.Books.Book;
import org.Manish.Books.BookRepo;

public class Main {
    public static void main(String[] args) {

        Book animalFarm= new Book("AnimalFarm","Abcd ","xyzcv");

        BookRepo bkr = new BookRepo();
        bkr.serach("AnimalFarm");
    }
}