# Java Basics

## Variables
Variables are named storage locations .Java is strictly typed language. To define a variable we have to first define a data type.

```Java
byte b =1;
short s =10;
int x = 15;
long l = 20;

float y=0.4f;
double d = 2.4;

char c ='e';
boolean flag=true;

//refrence data type

String name ="MK";

```
## Operators


