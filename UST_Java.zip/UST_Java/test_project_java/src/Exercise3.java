public class Exercise3 {

    public static void main(String[] args) {
        
        int[]nums={1,2,5,6,78,5};
        int sum=0;
        for(int num :nums)
        {
            sum+=num;
        }
        int avg=sum/nums.length;
        System.out.println("Sum : "+sum+" avg : "+avg);
    }
    
}
