public class Exercise6 {
    public static void main(String[] args) {
        int length =20;
        int width =10;

        int area = length*width;
        System.out.println(area);
    }
}
