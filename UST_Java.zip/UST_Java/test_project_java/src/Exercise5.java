public class Exercise5 {
    public static void main(String[] args) {
        
        int num1=50;
        int num2=67;

        if(num1>num2)
        {
            System.out.println(num1+" is greater");
        }else
        {
            System.out.println(num2+" is greater");
        }
    }
    
}
