public class Exercise2 {

    public static void main(String[] args) {

        int kilometer=5;
        int meter;

        meter= kilometer*1000;
        System.out.println(meter);

        
    }
    
}
