import javax.lang.model.util.ElementScanner14;

public class Exercise9 {

    public static void main(String[] args) {

        int a =5;
        int b=10;
        int c=15;

        if(a>=b && a>=c)
        {
            System.out.println(a+" Is greater");
        }else 
        if(b>=a && b>=c)
        {
            System.out.println(b+" Is greater");
        }else
        {
            System.out.println(c+" Is greater");
        }
        
    }
    
}
