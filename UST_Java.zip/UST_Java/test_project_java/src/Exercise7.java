public class Exercise7 {
    public static void main(String[] args) {

        int distance = 20;
        int speed=5;

        int time = distance/speed;

        System.out.println(time);
        
    }
}
