public class Exercise10 {

    public static void main(String[] args) {

        int age =20;
        if(age>0)
        {
            String ageGroup;
            if (age < 13) {
                ageGroup = "kid";
                System.out.println(ageGroup);
            } else if (age < 20) {
                ageGroup = "teenager";
                System.out.println(ageGroup);
            } else if (age < 60) {
                ageGroup = "adult";
                System.out.println(ageGroup);
            } else {
                ageGroup = "senior citizen";
                System.out.println(ageGroup);
            }
        }else
        {
            System.out.println("Enter Valid age");
        }
        
    }
    
}
