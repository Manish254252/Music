public class Exercise1 {
    public static void main(String[] args) {
        int number1 =20;
        int number2=5;
    
        if (number2 != 0) {
           
            int quotient = number1 / number2;           
            System.out.println("The quotient of " + number1 + " divided by " + number2 + " is: " + quotient);
        } else {
         
            System.out.println("Error: Division by zero is not allowed.");
        }

    }
}
