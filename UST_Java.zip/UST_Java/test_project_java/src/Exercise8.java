public class Exercise8 {

    public static void main(String[] args) {
        char x ='a';
        x=Character.toLowerCase(x);
        if(x=='a' || x=='e' ||x=='i' ||x=='o' ||x=='u')
        {
            System.out.println("is a vowel");
        }else 
        {
            System.out.println("not a vowel");
        }
    }
    
}
