public class Exercise4 {
    public static void main(String[] args) {

        int num =10;
        if(num%2==0)
        {
            System.out.println("even");
        }else
        {
            System.out.println("odd");
        }
        
    }
    
}
