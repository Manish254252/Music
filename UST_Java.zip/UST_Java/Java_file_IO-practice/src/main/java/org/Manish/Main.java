package org.Manish;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream("file.txt",true);
        String str = "Something in file ";
        fileOutputStream.write(str.getBytes());

        BufferedReader bufferedReader = new BufferedReader(new FileReader("file.txt"));
        String line ;
        while ((line= bufferedReader.readLine())!=null)
        {
            System.out.println(line);
        }

    }
}