package com.stackroute.collections;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryNumberGenerator {
    //write logic to find binary number from 1 to given input
    public String findBinaryNumbersSequence(int input) {
        StringBuilder str = new StringBuilder();
        if(input<=0)
        {
            return "Give proper input not zero or negative";
        }
        if(input>20)
            return "Give proper input not greater than 20";
        Queue<String> queue = new LinkedList<>();
        for (int i = 1; i <= input; i++) {
            String binary = Integer.toBinaryString(i);
            queue.offer(binary);
        }

        while (!queue.isEmpty()) {
            str.append(queue.poll()).append(" ");
        }
        return str.toString().trim() ;
    }
}