package org.Manish;

import org.Manish.Employee.*;
import org.Manish.Inventory.InventoryItem;
import org.Manish.Inventory.MedicalRecord;
import org.Manish.Inventory.MedicalRecordManager;
import org.Manish.Inventory.Pharmacist;

public class Main {
    public static void main(String[] args) {
        // Create instances of different classes and perform operations
        Doctor doctor = new Doctor("Dr. Smith", "D001", "Outpatient");
        Nurse nurse = new Nurse("Nurse Johnson", "N001", "Inpatient");
        Receptionist receptionist = new Receptionist();
        Pharmacist pharmacist = new Pharmacist("Pharmacist Brown", "P001", "Pharmacy");

        // Add employee to respective departments
        HRStaff hrStaff = new HRStaff();
        hrStaff.addEmployee(doctor);
        hrStaff.addEmployee(nurse);
        hrStaff.addEmployee(pharmacist);

        // Schedule appointment for patient
        Patient patient = new Patient("John Doe", "P001", "Outpatient");
        receptionist.scheduleAppointment(patient);

        // Admit patient to inpatient department
        nurse.admitPatient(patient);

        // Consult patient
        doctor.consultPatient(patient);

        // Manage inventory
        InventoryItem item = new InventoryItem("Medicine A", 100);
        pharmacist.addToInventory(item);

        // Create, update, and retrieve medical record
        MedicalRecordManager recordManager = new MedicalRecordManager();
        recordManager.createMedicalRecord(patient, "Fever", "Medicine A");
        MedicalRecord medicalRecord = recordManager.retrieveMedicalRecord(patient);
        System.out.println(medicalRecord);
        if (medicalRecord != null) {
            recordManager.updateMedicalRecord(medicalRecord, "Flu", "Medicine B");
        }
    }
}