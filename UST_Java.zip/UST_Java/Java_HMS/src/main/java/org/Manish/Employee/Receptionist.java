package org.Manish.Employee;


import java.time.LocalDateTime;
import java.util.*;

public class Receptionist {
    // Method to schedule appointments for patients
    private final Map<Patient, LocalDateTime> schedule ;

    public Receptionist() {
     schedule = new HashMap<>();
    }

    public void scheduleAppointment(Patient patient) {
        // Logic to schedule appointment
        if(schedule.isEmpty())
        {
            schedule.put(patient,LocalDateTime.now().plusMinutes(10));
        }else {
            List<Map.Entry<Patient,LocalDateTime>> appointments = new ArrayList<>(schedule.entrySet());


            LocalDateTime scheduleTime= appointments.getLast().getValue().plusMinutes(30);
            schedule.put(patient,scheduleTime);
        }
    }
}
