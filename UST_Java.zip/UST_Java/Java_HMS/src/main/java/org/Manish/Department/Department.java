package org.Manish.Department;

import org.Manish.Employee.Employee;

import java.util.ArrayList;
import java.util.List;

public abstract class Department extends Employee {
    private String name;
    private List<Employee> employees;

    // Constructor
    public Department(String name) {
        super();
        this.name = name;
        this.employees = new ArrayList<>();
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    // Method to add employee to department
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }
}
