package org.Manish.Employee;

public class Doctor extends Employee {
    // Constructor
    public Doctor(String name, String id, String department) {
        super(name, id, department);
    }

    public Doctor() {

    }

    @Override
    public void updateDetails(Employee employee) {
        Doctor doctor = new Doctor();
        doctor.setName(employee.getName());
        doctor.setDepartment(employee.getDepartment());
        doctor.setId(employee.getId());

    }





    // Method to consult patients, diagnose, and prescribe medications
    public void consultPatient(Patient patient) {

       String a=  patient.getName();
        String b =patient.getDepartment();
        System.out.println("Patient "+a+" is consulted"+" from "+b+" Department");
    }


}
