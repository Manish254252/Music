package org.Manish.Inventory;

import org.Manish.Employee.Patient;

public class MedicalRecord {
    private Patient patient;
    private String diagnosis;
    private String prescription;

    // Constructor
    public MedicalRecord(Patient patient, String diagnosis, String prescription) {
        this.patient = patient;
        this.diagnosis = diagnosis;
        this.prescription = prescription;
    }

    // Getters and setters
    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getPrescription() {
        return prescription;
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }

    @Override
    public String toString() {
        return "MedicalRecord{" +
                "patient=" + patient +
                ", diagnosis='" + diagnosis + '\'' +
                ", prescription='" + prescription + '\'' +
                '}';
    }
}
