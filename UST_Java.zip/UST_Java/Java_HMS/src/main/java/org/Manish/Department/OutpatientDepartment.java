package org.Manish.Department;

import org.Manish.Employee.Employee;

class OutpatientDepartment extends Department {
    // Constructor
    public OutpatientDepartment(String name) {
        super(name);
    }

    // Method specific to outpatient department
    public void scheduleAppointment() {
        // Logic to schedule appointments
    }



    @Override
    public void updateDetails(Employee employee) {

    }
}
