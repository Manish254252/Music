package org.Manish.Inventory;

import org.Manish.Employee.Patient;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class MedicalRecordManager {
   List<MedicalRecord> medicalRecordList;
    public MedicalRecordManager() {
        medicalRecordList = new LinkedList<>();

    }

    public void createMedicalRecord(Patient patient, String diagnosis, String prescription) {
        MedicalRecord medicalRecord = new MedicalRecord(patient,diagnosis,prescription);
        medicalRecordList.add(medicalRecord);
    }


    public void updateMedicalRecord(MedicalRecord record, String diagnosis, String prescription) {

        for (MedicalRecord mr :medicalRecordList)
        {
            if(mr.getPatient().equals(record.getPatient()))
            {
                mr.getPatient().setName(record.getPatient().getName());
                mr.getPatient().setDepartment(record.getPatient().getDepartment());
                mr.getPatient().setId(record.getPatient().getId());
            }
        }

    }


    public MedicalRecord retrieveMedicalRecord(Patient patient) {

        for(MedicalRecord mr : medicalRecordList)
        {

            if(mr.getPatient().equals(patient))
            {

                return mr;
            }
        }

        return null;
    }
}
