package org.Manish.Employee;

import java.util.LinkedList;
import java.util.List;

public class HRStaff {
    // Method to add new employees to respective departments
    private List<Employee> staff;

    public HRStaff() {
        staff = new LinkedList<>();
    }

    public void addEmployee(Employee employee) {
        // Logic to add employee
        staff.add(employee);
    }
}