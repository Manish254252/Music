package org.Manish.Department;

import org.Manish.Employee.Employee;

public class EmergencyDepartment extends Department {
    // Constructor
    public EmergencyDepartment(String name) {
        super(name);
    }

    // Method specific to emergency department
    public void handleEmergency() {
        // Logic to handle emergency cases
    }



    @Override
    public void updateDetails(Employee employee) {

    }
}
