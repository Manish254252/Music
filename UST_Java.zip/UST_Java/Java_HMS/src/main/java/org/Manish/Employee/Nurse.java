package org.Manish.Employee;

import java.util.LinkedList;
import java.util.List;

public class Nurse extends Employee {
    // Constructor
    private List<Patient> admittedPatientList;
    public Nurse(String name, String id, String department) {

        super(name, id, department);
        admittedPatientList = new LinkedList<>();
    }

    public Nurse() {


    }

    @Override
    public void updateDetails(Employee employee) {
        Nurse nurse = new Nurse();
        nurse.setName(employee.getName());
        nurse.setDepartment(employee.getDepartment());
        nurse.setId(employee.getId());
    }



    public void admitPatient(Patient patient) {

        admittedPatientList.add(patient);
        System.out.println("Patient "+patient.getName()+" is admitted");

    }
}
