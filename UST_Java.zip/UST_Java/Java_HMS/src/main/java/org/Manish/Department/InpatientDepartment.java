package org.Manish.Department;

import org.Manish.Employee.Employee;

class InpatientDepartment extends Department {
    // Constructor
    public InpatientDepartment(String name) {
        super(name);
    }

    // Method specific to inpatient department
    public void manageAdmissions() {
        // Logic to manage patient admissions
    }


    @Override
    public void updateDetails(Employee employee) {

    }
}
