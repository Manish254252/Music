package org.Manish.Inventory;


import org.Manish.Employee.Employee;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Pharmacist extends Employee {
    private List<InventoryItem> inventoryItemMap;
    // Constructor
    public Pharmacist(String name, String id, String department) {
        super(name, id, department);
        inventoryItemMap = new LinkedList<>();
    }

    public Pharmacist() {

    }

    @Override
    public void updateDetails(Employee employee) {
        Pharmacist pharmacist = new Pharmacist();
        pharmacist.setName(employee.getName());
        pharmacist.setDepartment(employee.getDepartment());
        pharmacist.setId(employee.getId());

    }







    public void addToInventory(InventoryItem item) {

        inventoryItemMap.add(item);
        System.out.println("Item "+item.getName()+" added to inventory");

    }
}

