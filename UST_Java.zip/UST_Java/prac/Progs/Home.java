public class Home {

    public static void main(String[] args) {
        int []array={1,2,3,6,3,6,1};
        int []num=new int[10];
        for (int i = 0; i < array.length; i++) {
            num[array[i]]=num[array[i]]++;

        }
        String repeat ="";
        for (int i = 0; i < num.length; i++) {

            if(num[i]>=2)
            {
                repeat=num[i]+" ,";
            }

        }
        System.out.println(repeat);

    }
}