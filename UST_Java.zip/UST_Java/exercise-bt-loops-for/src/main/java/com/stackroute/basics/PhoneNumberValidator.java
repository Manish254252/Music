package com.stackroute.basics;

import java.util.Scanner;
import java.util.StringTokenizer;

public class PhoneNumberValidator {
    //Create Scanner object as instance variable
    Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        PhoneNumberValidator object = new PhoneNumberValidator();
        String input = object.getInput();
        boolean result = object.validatePhoneNumber(input);
        object.displayResult(result);
    }

    public String getInput() {
        String str = sc.nextLine();
      return str;
    }

    public void displayResult(boolean result) {
       if(result)
       {
           System.out.println("Valid");
       }else {
           System.out.println("invalidoremptystring");
       }
    }

    public boolean validatePhoneNumber(String s) {
        int count=0;
       if(s!=null)
       {
           char[] carr= s.toCharArray();

           for (int i = 0; i < carr.length; i++) {

               if(carr[i]=='0'|| carr[i]=='1'||carr[i]=='2'||carr[i]=='3'||carr[i]=='4'||carr[i]=='5'
                       ||carr[i]=='6'||carr[i]=='7'||carr[i]=='8'||carr[i]=='9')
               {
                   count++;
               }else if(carr[i]!='-')
               {
                   return false;
               }


           }
       }else {
           return false;
       }

        if(count==10)
        {
            return  true;
        }
        return false;
    }
}
