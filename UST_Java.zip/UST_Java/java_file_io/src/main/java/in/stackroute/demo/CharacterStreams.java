package in.stackroute.demo;

import java.io.*;

public class CharacterStreams {

    public static void read() throws IOException {
        FileReader reader = new FileReader("data.txt");
        BufferedReader bufferedReader = new BufferedReader(reader);
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            System.out.println(line);
        }
        bufferedReader.close();
        reader.close();
    }

    public static void write(String data) throws  IOException{
        FileWriter writer = new FileWriter("out2.txt", true);
        PrintWriter printWriter = new PrintWriter(writer);
        printWriter.println(data);
        printWriter.flush();
        writer.flush();
        writer.close();
    }
}
