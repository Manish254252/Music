package in.stackroute.store;

import java.io.Serializable;

public record Item(String code, String name, float price) implements Serializable {
}
