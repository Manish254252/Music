package in.stackroute;

import java.util.Arrays;

public class demo111 {
    public static void main(String[] args) {
        boolean[] alpha = new boolean[26];
        Arrays.fill(alpha,false);
        String s  = "nmb";
        char[] str = s.toCharArray();
        for (int i = 0; i < str.length; i++) {

            if(alpha[str[i]-'a'])
            {
                System.out.println("false");
                break;
            }
            alpha[str[i]-'a']=true;
        }

        System.out.println("true");
    }
}
