package in.stackroute;


import in.stackroute.store.Inventory;
import in.stackroute.store.Item;

import java.io.IOException;


public class Main {
    public static void main(String[] args) {
        try {
            Inventory inventory = new Inventory();

            inventory.addItem(new Item("CGL", "Colgate", 20.12f));
            inventory.addItem(new Item("SNK", "Snickers", 40.23f));

            System.out.println(inventory.getInventory());

            /*
             * CGL-Colgate-20.12
             * SNK-Snickers-4023
             */
            inventory.persistInventory("Inventory.txt");
            inventory.loadInventory("Inventory.txt");

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}