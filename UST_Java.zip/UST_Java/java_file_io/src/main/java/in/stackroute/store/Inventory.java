package in.stackroute.store;

import java.io.*;
import java.util.LinkedList;
import java.util.List;

public class Inventory {

    private final List<Item> inventory;
    private final List<Item> inventoryStoring;

    public Inventory() {
        this.inventoryStoring = new LinkedList<>();
        this.inventory = new LinkedList<>();
    }

    public void addItem(Item item) {
        inventory.add(item);
    }
    public void addItemFromFile(Item item) {
        inventoryStoring.add(item);
    }

    public List<Item> getInventory() {
        return inventory;
    }
    public List<Item> getInventoryFromFile() {
        return inventoryStoring;
    }


    /**
     * The data in the inventory must be stored into the file in the following format.
     * code-name-price
     * CDPR-CD ProjectRed-150.23
     *
     * @param fileName name of the file
     */
    public void persistInventory(String fileName) throws IOException {
        File file = new File(fileName);
        if(!file.exists())
        {
            throw new FileNotFoundException();
        }

        PrintWriter printWriter = new PrintWriter(new FileWriter(fileName,false));
        StringBuilder builder = new StringBuilder();
        for(Item item:inventory)
        {
            String line = String.format("%s,%s,%s",item.code(),item.name(),item.price());
            builder.append(line);
            builder.append("\n");
        }

        printWriter.println(builder);
        printWriter.flush();
        printWriter.close();




//


    }
    public void serialization (String fileName) throws IOException {
        ObjectOutputStream printObject = new ObjectOutputStream(new FileOutputStream(fileName,false));
        for(Item item:inventory)
        {
                printObject.writeObject(item);
        }
    }

    public Item deSerialization (String fileName) throws IOException {
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(fileName))) {
            // Read objects until the end of file
            while (true) {
                try {
                    Item obj = (Item) inputStream.readObject();
//                    System.out.println("Object has been read from file: " + obj.name() + " = " + obj.price());
                    return obj;
                } catch (EOFException e) {
                    // End of file reached
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        return  null;

    }
    /**
     * Load the data from the file and convert it into a list.
     *
     * @param fileName name of the file
     */
    public void loadInventory(String fileName) throws IOException {
/*
   implemented loadInventory using BufferReader
 */
        BufferedReader bufferedReader = new BufferedReader( new FileReader(fileName));
        String line;
        while ((line=bufferedReader.readLine())!=null && !line.isEmpty())
        {
            addItemFromFile(new Item(line.split(",")[0],line.split(",")[1],Float.parseFloat(line.split(",")[2])));
//            System.out.println(line.split(",")[1]+" = "+line.split(",")[2]);
        }
        bufferedReader.close();
/*
   implemented loadInventory using ObjectReader
// */
//



    }
}
