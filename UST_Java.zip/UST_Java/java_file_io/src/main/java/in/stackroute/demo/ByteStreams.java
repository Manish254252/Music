package in.stackroute.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreams {

    public static void read() throws IOException {
        FileInputStream input = new FileInputStream("data.txt"); // open the stream
        int count;
        count = input.read();
        do {
            System.out.print((char) count);
            count = input.read();
        } while (count != -1);
        input.close(); // close the stream
    }

    public static void write(String data) throws IOException {
        FileOutputStream output = new FileOutputStream("out.txt", true);
        output.write(data.getBytes());
        output.flush();
        output.close();
    }
}
