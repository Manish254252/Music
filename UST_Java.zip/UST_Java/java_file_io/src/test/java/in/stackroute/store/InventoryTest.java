package in.stackroute.store;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {
    Inventory inventory;
    Item i1;
    Item i2;
    @BeforeEach
    void setUp() {
        inventory = new Inventory();
        i1=new Item("CGL", "Colgate", 20.12f);
         i2 = new Item("SNK", "Snickers", 40.23f);


    }

    @AfterEach
    void tearDown() {
        inventory=null;
    }

    @Test
    void addItem() {
        inventory.addItem(i1);
        Item item = inventory.getInventory().getFirst();
        assertAll(()->assertEquals("CGL",item.code()),
                  ()->assertEquals("Colgate",item.name()),
                ()->assertEquals(20.12f,item.price()));
    }

    @Test
    void getInventory() {
        inventory.addItem(i1);
        Item item = inventory.getInventory().getFirst();
        assertAll(()->assertEquals("CGL",item.code()),
                ()->assertEquals("Colgate",item.name()),
                ()->assertEquals(20.12f,item.price()));

    }

    @Test
    void persistInventory() throws IOException {
        inventory.addItem(i1);
        inventory.addItem(i2);
        inventory.persistInventory("test.txt");
        inventory.loadInventory("test.txt");
        Item temp = inventory.getInventoryFromFile().getFirst();
        Item temp2 = inventory.getInventoryFromFile().getLast();

        assertAll(()->assertEquals("CGL",temp.code()),
                ()->assertEquals("Colgate",temp.name()),
                ()->assertEquals(20.12f,temp.price()));
        assertAll(()->assertEquals("SNK",temp2.code()),
                ()->assertEquals("Snickers",temp2.name()),
                ()->assertEquals(40.23f,temp2.price()));
    }

    @Test
    void loadInventory() throws IOException {

        inventory.addItem(i1);
        inventory.addItem(i2);
        inventory.persistInventory("test.txt");
        inventory.loadInventory("test.txt");
        Item temp = inventory.getInventory().getFirst();
        Item temp2 = inventory.getInventory().getLast();

        assertAll(()->assertEquals("CGL",temp.code()),
                ()->assertEquals("Colgate",temp.name()),
                ()->assertEquals(20.12f,temp.price()));
        assertAll(()->assertEquals("SNK",temp2.code()),
                ()->assertEquals("Snickers",temp2.name()),
                ()->assertEquals(40.23f,temp2.price()));
    }
    @Test
    void ifFileExists() throws IOException {
        assertThrows(FileNotFoundException.class,()->inventory.persistInventory("qwert1233"));

    }

    @Test
    void serialization() throws IOException {
        inventory.addItem(i1);
        inventory.serialization("test.txt");
       Item item = inventory.deSerialization("test.txt");
       assertEquals("Item",item.getClass().getSimpleName());

    }

    @Test
    void deSerialization() throws IOException {
        inventory.addItem(i1);
        inventory.serialization("test.txt");
        inventory.deSerialization("test.txt");
        Item item = inventory.deSerialization("test.txt");
        System.out.println(item);
        assertEquals("Item",item.getClass().getSimpleName());

        assertAll(()->assertEquals("CGL",item.code()),
                ()->assertEquals("Colgate",item.name()),
                ()->assertEquals(20.12f,item.price()));
    }
}