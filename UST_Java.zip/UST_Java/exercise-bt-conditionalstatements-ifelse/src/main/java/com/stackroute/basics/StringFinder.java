package com.stackroute.basics;

import java.util.Scanner;

public class StringFinder {
    //Create Scanner object as instance variable
    Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        //Get three strings from the user

        new StringFinder().getInput();
    }

    public String getInput() {


//        System.out.print("Enter the search string: ");
        String searchString = scanner.nextLine();

//        System.out.print("Enter the first string: ");
        String firstString = scanner.nextLine();

//        System.out.print("Enter the second string: ");
        String secondString = scanner.nextLine();

        int result = findString(searchString, firstString, secondString);
        displayResult(result);

        closeScanner();
        return null;


    }

    public void displayResult(int result) {
//        System.out.println(result);
        if (result == 0) {
            System.out.println("Not found");
        }
        if(result==1){
            System.out.println("Found as expected");
        }
        if(result==-1)
        {
            System.out.println("Empty string or null");
        }
        //displays the result
    }

    public int findString(String searchString, String firstString, String secondString) {
//        int res;
        if (searchString == null || firstString == null || secondString == null ||
                searchString.isEmpty() || firstString.isEmpty() || secondString.isEmpty()) {
            return -1; // Indicate that input is invalid
        }

        int firstIndex = searchString.indexOf(firstString);
        int secondIndex = searchString.indexOf(secondString);

        if (firstIndex == -1 || secondIndex==-1)
        {
            return 0; // Indicates that one of the strings is not found in the search string
        }

        if (secondIndex > firstIndex) {
            return 1; // Indicates that the second string comes after the first string
        } else {
            return 0; // Indicates that the second string does not come after the first string
        }



    }

    public void closeScanner() {
        if (scanner != null) {
            scanner.close();
        }
    }
}
