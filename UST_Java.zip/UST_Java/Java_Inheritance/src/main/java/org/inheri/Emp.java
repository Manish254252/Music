package org.inheri;

public class Emp {


    private String fullname;
    private  String department;
    private  String email;
    private long empId;

    public Emp() {
    }

    public Emp(String fullname, String department, String email, long empId) {
        this.fullname = fullname;
        this.department = department;
        this.email = email;
        this.empId = empId;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getEmpId() {
        return empId;
    }

    public void setEmpId(long empId) {
        this.empId = empId;
    }
}
