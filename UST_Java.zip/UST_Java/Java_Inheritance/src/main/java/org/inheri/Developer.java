package org.inheri;

public class Developer {
}
