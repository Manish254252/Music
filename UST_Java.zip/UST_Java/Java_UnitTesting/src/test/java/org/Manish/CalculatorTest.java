package org.Manish;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTest {
//    Calculator calc = new Calculator();
    Calculator calc ;
    @BeforeEach
    void setUp() {
     calc = new Calculator();
    }

    @AfterEach
    void tearDown() {
        calc=null;
    }



    @DisplayName("Sum Of Two")
    @Test
    void sum() {
       assertEquals(10,calc.sum(5,5));
       assertEquals(5,calc.sum(2,3));
       assertEquals(3,calc.sum(0,3));

    }
    @DisplayName("Subtraction")
    @Test
    void subtract() {
        assertEquals(15,calc.subtract(20,5));
        assertEquals(-5,calc.subtract(0,5));
    }
    @DisplayName("Multiplication")
    @Test
    void multiply() {
        assertEquals(25,calc.multiply(5,5));
        assertEquals(0,calc.multiply(0,5));
        assertEquals(5,calc.multiply(1,5));
    }
    @DisplayName("Division")
    @Test
    void divide() {
        assertEquals(4,calc.divide(20,5));
        Exception exception = assertThrows(IllegalArgumentException.class,()->calc.divide(20,0));
        assertEquals("Division by zero is not allowed",exception.getMessage());

    }
}