package org.Manish.Library;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LBSTest {
LBS lbd ;
    Book bk;
    Book bk1;

    @BeforeEach
    void setUp() {
        lbd = new LBS();
        bk = new Book("Abc of db ","RDBMS","Coder");
        bk1 = new Book("Abc of db 1 ","1RDBMS","Coder1");

    }

    @AfterEach
    void tearDown() {
        lbd=null;
        bk=null;
    }

    @Test
    void addBookIfExist() {
        lbd.addBook(bk);
        lbd.addBook(bk);
        assertEquals(1,lbd.getBookList().size());
    }
    @Test
    void addBookIfNotProperValue() {
        Book bk22 = new Book("","","");
//        lbd.addBook(bk22);

        assertEquals("Book not have proper values",lbd.addBook(bk22));
    }
    @Test
    void addBookIfDifferent() {
        lbd.addBook(bk);
        lbd.addBook(bk1);
        assertNotEquals(bk, bk1);
    }
    @Test
    void addBookIfNotExist() {
        lbd.addBook(bk);
//        Book book = lbd.getBookList().getFirst();
        assertEquals(bk,lbd.getBookList().getFirst());


    }

    @Test
    void removeBookIfNotExist() {
        Book b1 = new Book("abc","bvc","sdf");
        assertEquals("There is no such Book",lbd.removeBook(b1));
    } @Test
    void removeBookIfExist() {
        Book b1 = new Book("abc","bvc","sdf");
        lbd.addBook(b1);
        assertEquals("Book removed",lbd.removeBook(b1));
    }

    @Test
    void searchBook()
    {
        lbd.addBook(bk);
        assertEquals(bk,lbd.searchBook(bk.getTitle()));
    }
    @Test
    void searchBookNotPresent()
    {

        assertNull(lbd.searchBook("abc"));
    }

    @Test
    void getList()
    {
        lbd.addBook(bk);
        assertEquals(1,lbd.getBookList().size());
    }
}