package org.Manish.Product;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class ProductValidatorTest {
    @Test
    public void testIsExpiredWhenNotExpired() {
        Product product = new Product("CRL", "Crest", 10, LocalDate.now(), 6, UsagePeriod.MONTHS);
        ProductValidator validator = new ProductValidator();
        boolean expired = validator.isExpired(product);
        assertFalse(expired);
    }



    @Test
    public void testIsExpiredWhenExpired() {
        Product product = new Product("ORS", "Oral-B", 25, LocalDate.of(2024,01,01), 90, UsagePeriod.DAYS);
        ProductValidator validator = new ProductValidator();
        boolean expired = validator.isExpired(product);
        assertTrue(expired);
    }

    @Test
    public void testIsExpiredWhenManufacturedToday() {
        Product product = new Product("ORS", "Oral-B", 25, LocalDate.now(), 0, UsagePeriod.DAYS);
        ProductValidator validator = new ProductValidator();
        boolean expired = validator.isExpired(product);
        assertFalse(expired);
    }

    @Test
    public void testIsExpiredWhenManufacturedInTheFuture() {
        Product product = new Product("CRL", "Crest", 10, LocalDate.now().plusDays(10), 6, UsagePeriod.MONTHS);
        ProductValidator validator = new ProductValidator();
        boolean expired = validator.isExpired(product);
        assertFalse(expired);
    }

}