package org.Manish.Library;

import java.util.ArrayList;
import java.util.List;

public class LBS {
   private List<Book> bookList;
    public LBS() {
        bookList=new ArrayList<>();
    }

    public List<Book> getBookList() {
        return bookList;
    }

    public String addBook(Book book)
    {
        if(!bookList.contains(book))
        {
            if(!(book.getTitle()==null || book.getTitle().isEmpty() || book.getAuthor()==null||book.getAuthor().isEmpty() ||book.getPublisher()==null||book.getPublisher().isEmpty()))
            {
                bookList.add(book);
                return "Book Added";
            }else
            {
                return "Book not have proper values";
            }
        }

return null;


    }

    public Book searchBook(String bookName) {

        for(Book bk:bookList)
        {
            if(bk.getTitle().equals(bookName))
            {
                return bk;
            }
        }
        return null;
    }

    public String removeBook(Book book)
    {
        if(bookList.contains(book))
        {
            bookList.remove(book);
            return "Book removed";
        }else {
          return   "There is no such Book";
        }
    }
}
