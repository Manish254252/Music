package org.Manish.Product;


import lombok.*;

import java.time.LocalDate;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class Product {

    private String code;
    private String name;
    private float unitPrice;
    private LocalDate manufacturedDate;
    private int usableDuration;
    private UsagePeriod period;

}
