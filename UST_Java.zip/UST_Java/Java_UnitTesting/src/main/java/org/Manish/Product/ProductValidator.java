package org.Manish.Product;


import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class ProductValidator {

    /**
     * Check if the producted is expired based on the manufacturedDate, ussableDuration and period.
     *
     * @return boolean
     */
    public boolean isExpired(Product product) {
        LocalDate today = LocalDate.now();

        LocalDate some = product.getManufacturedDate().plusDays(product.getUsableDuration());
        System.out.println(some);
        LocalDate expirationDate =product.getManufacturedDate().plus(product.getUsableDuration(), getProductChronoUnit(UsagePeriod.DAYS));
        System.out.println(expirationDate);
        return today.isAfter(expirationDate);

    }
    private ChronoUnit getProductChronoUnit(UsagePeriod period) {
        switch (period) {
            case DAYS:
                return ChronoUnit.DAYS;
            case MONTHS:
                return ChronoUnit.MONTHS;
            case YEARS:
                return ChronoUnit.YEARS;
            default:
                throw new IllegalArgumentException("Unsupported period: " + period);
        }
        }
}
