package org.Manish.Library;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
public class Book {

    private String title;
    private String author;

    private String publisher;
}
