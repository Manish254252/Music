package com.stackroute.basics;


import java.util.Scanner;

public class NumberAverage {

    public static void main(String[] args) {
        new NumberAverage().getArrayValues();
    }


    //get the values of the array from the user
    public void getArrayValues() {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

       if(n>0)
       {
           int[] arr = new int[n];
           for (int i = 0; i < arr.length; i++) {
               arr[i]= sc.nextInt();

           }
           String avg = findAverage(arr);
           System.out.println(avg);
       }else {
           System.out.println("Empty array");
       }


    }

    //write here logic to calculate the average an array
    public String findAverage(int[] inputArray) {
        String avg="";
        int sum=0;
        int count=0;
        if(inputArray.length==0)
        {
            System.out.println("Empty array");
        }else {
            for(int x:inputArray)
            {
                if(x<0)
                {
                    return "Give proper positive integer values";
                }
                sum+=x;
                count++;
            }
        }
        if(count>1)
            avg=(sum/count)+"";
        else
            return "Empty array";
        return "The average value is: "+avg;
    }
}
