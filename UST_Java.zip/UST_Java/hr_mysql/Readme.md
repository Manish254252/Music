# HR Database for MySQL Practice

Plesae follow the instructions below to create a database for HR department.
1. Execute the `db.sql` script to create the database and tables.

## Schema

`The HR database schema is as follows`\
![HR Schema](./model.gif)

## Tasks

- [Select statement questions](./select.md)
- [Sorting and Filtering](./sorting.md)
