import org.testng.annotations.Test;

public class TestJava {
    @Test
    public void aTest1()
    {
        System.out.println("Test 1 Passed ");
    }@Test
    public void bTest1()
    {
        System.out.println("Test 2 Passed ");
    }@Test
    public void cTest1()
    {
        System.out.println("Test 3 Passed ");
    }@Test
    public void dTest1()
    {
        System.out.println("Test 4 Passed ");
    }
}
