package com.stackroute.exercises;

import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalDate;

public class FindDay {

    // Write logic to find day of the date and return result
    public String findDay(int month, int day, int year) {
        if(year>2999)
            return "Give year in range";
        try {
            LocalDate date = LocalDate.of(year, month, day);
            DayOfWeek dayOfWeek = date.getDayOfWeek();
            return dayOfWeek.toString();
        } catch (DateTimeException e) {
            String errorMessage = "";
            if (month <= 0 || month >= 13) {
                errorMessage += "Give month in range";
            }
            if (day <= 0 || day >= 32) {
                errorMessage += "Give day in range";
            }if (year <= 1999 || year > 2999) {
                errorMessage += "Give year in range";
            }
            return errorMessage + "";
        }
    }
}
