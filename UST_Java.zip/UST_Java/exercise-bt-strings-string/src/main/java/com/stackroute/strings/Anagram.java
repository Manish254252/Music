package com.stackroute.strings;

import java.util.Arrays;

public class Anagram {
    //write logic to check given two phrases are anagrams or not and return result
    public String checkAnagrams(String phraseOne, String phraseTwo) {
        String str1 = phraseOne.replaceAll("\\s", "");
        String str2 = phraseTwo.replaceAll("\\s", "");

        if(phraseOne.isEmpty() || phraseTwo.isEmpty())
        {
            return "Give proper input not empty phrases";
        }
        if (phraseOne.length() != phraseTwo.length()) {
            return "Given phrases are not anagrams";
        }
        char[] charArray1 = str1.toCharArray();
        char[] charArray2 = str2.toCharArray();

        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        // Check if the sorted arrays are equal
        if( Arrays.equals(charArray1, charArray2))
        {
            return "Given phrases are anagrams";
        }
        return "Given phrases are not anagrams";
    }
}
